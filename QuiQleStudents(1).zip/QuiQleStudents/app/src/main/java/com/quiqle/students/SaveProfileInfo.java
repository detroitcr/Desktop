package com.quiqle.students;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.quiqle.students.SaveData.Student;

public class SaveProfileInfo extends AppCompatActivity {

    String mobile;

    TextView phone;

    EditText names, emails;
    Spinner chooseClasss, fieldOfStudys;
    Button submit;

    DatabaseReference databaseReference;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_save_profile_info);

        Intent intent = getIntent();
        mobile = intent.getStringExtra("mobile");

        //Initialize all EditText, buttons and  Spinners
        names = findViewById(R.id.name);
        emails = findViewById(R.id.email);
        chooseClasss = findViewById(R.id.chooseClass);
        fieldOfStudys = findViewById(R.id.fieldOfStudy);
        submit = findViewById(R.id.submit);
        phone = findViewById(R.id.phone);

        phone.setText(mobile);

        //Submit Details onClick
        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent intent = new Intent(SaveProfileInfo.this, Home.class);
                startActivity(intent);
                addDetails();

            }
        });

        //Database Reference
        databaseReference = FirebaseDatabase.getInstance().getReference("students");

    }

    private void addDetails(){

       String name = names.getText().toString().trim();
       String email = emails.getText().toString().trim();
       String chooseClass  = chooseClasss.getSelectedItem().toString();
       String fieldOfStudy = fieldOfStudys.getSelectedItem().toString();
       String mobiles = phone.getText().toString();

       if (!TextUtils.isEmpty(name)){

           String id = databaseReference.push().getKey();

           Student student = new Student(id,name,email,chooseClass,fieldOfStudy,mobiles);

           databaseReference.child(id).setValue(student);

           Toast.makeText(this, "Profile Submitted", Toast.LENGTH_SHORT).show();

       }
       else {
           Toast.makeText(this, "Please Enter Full Name", Toast.LENGTH_SHORT).show();

       }

    }
}
