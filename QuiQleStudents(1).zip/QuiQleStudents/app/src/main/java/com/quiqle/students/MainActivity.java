package com.quiqle.students;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {

    EditText phone;
    Button btnLogin;

    String phoneNumber;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        btnLogin = findViewById(R.id.btnLogin);
        phone = findViewById(R.id.phone);

       btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                phoneNumber = phone.getText().toString();
                if (checkvalidation()){

                    Intent intent = new Intent(MainActivity.this, Verification.class);
                    intent.putExtra("mobile",phoneNumber);
                    startActivity(intent);
                }

            }
        });




    }

    private Boolean checkvalidation()
    {   Boolean check =true;
        if(TextUtils.isEmpty(phoneNumber))
        {
            phone.setError("Required");
            check=false;
        }
        if( !(phoneNumber.length()==10))
        {
            phone.setError("Not valid");
            check=false;
        }
        return check;
    }
}
