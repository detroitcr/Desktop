package com.quiqle.students;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import android.os.Bundle;
import android.view.MenuItem;

import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.quiqle.students.Fragments.HireFragment;
import com.quiqle.students.Fragments.HomeFragment;
import com.quiqle.students.Fragments.ProfileFragment;
import com.quiqle.students.Fragments.WorkFragment;

public class Home extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        BottomNavigationView bottomNavigationView = findViewById(R.id.bottomNavigation);

        bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {

                    int id = menuItem.getItemId();

                  if (id == R.id.home){

                      HomeFragment homeFragment = new HomeFragment();
                      FragmentTransaction fragmentTransaction = getSupportFragmentManager().beginTransaction();
                      fragmentTransaction.replace(R.id.fragmentContainer,homeFragment);
                      fragmentTransaction.commit();

                  }

                if (id == R.id.hire){

                    HireFragment hireFragment = new HireFragment();
                    FragmentTransaction fragmentTransaction = getSupportFragmentManager().beginTransaction();
                    fragmentTransaction.replace(R.id.fragmentContainer,hireFragment);
                    fragmentTransaction.commit();

                }
                if (id == R.id.work){

                    WorkFragment workFragment = new WorkFragment();
                    FragmentTransaction fragmentTransaction = getSupportFragmentManager().beginTransaction();
                    fragmentTransaction.replace(R.id.fragmentContainer,workFragment);
                    fragmentTransaction.commit();

                }
                if (id == R.id.profile){

                    ProfileFragment profileFragment = new ProfileFragment();
                    FragmentTransaction fragmentTransaction = getSupportFragmentManager().beginTransaction();
                    fragmentTransaction.replace(R.id.fragmentContainer,profileFragment);
                    fragmentTransaction.commit();

                }
                return true;
            }
        });

        bottomNavigationView.setSelectedItemId(R.id.home);

    }
}
