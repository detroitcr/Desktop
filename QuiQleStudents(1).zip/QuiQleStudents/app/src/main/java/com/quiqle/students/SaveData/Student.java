package com.quiqle.students.SaveData;

public class Student {

    String STUDENTID;
    String NAME;
    String EMAIL;
    String CLASS;
    String FIELDOFSTUDY;
    String PHONE;

    public Student(){

    }

    public Student(String STUDENTID, String NAME, String EMAIL, String CLASS, String FIELDOFSTUDY, String PHONE) {
        this.STUDENTID = STUDENTID;
        this.NAME = NAME;
        this.EMAIL = EMAIL;
        this.CLASS = CLASS;
        this.FIELDOFSTUDY = FIELDOFSTUDY;
        this.PHONE = PHONE;
    }

    public String getPHONE() {
        return PHONE;
    }

    public String getSTUDENTID() {
        return STUDENTID;
    }

    public String getNAME() {
        return NAME;
    }

    public String getEMAIL() {
        return EMAIL;
    }

    public String getCLASS() {
        return CLASS;
    }

    public String getFIELDOFSTUDY() {
        return FIELDOFSTUDY;
    }
}
